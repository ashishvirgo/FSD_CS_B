import React from 'react'

const Footer = () => {
  return (
    <div>
      <h3><center>Design and Developed By &copy; FSD Team</center></h3>
    </div>
  )
}

export default Footer
